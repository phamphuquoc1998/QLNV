package com.ppq.phamphuquoc.phamphuquocassignment;

/**
 * Created by ADMIN on 08/17/2017.
 */

public class NhanVien {
    private String tenNV;
    private String maNV;
    private String age;
    private String Email;
    private String Phone;
    private String diaChi;

    public NhanVien() {
    }

    public NhanVien(String tenNV, String maNV, String age, String email, String phone, String diaChi) {
        this.tenNV = tenNV;
        this.maNV = maNV;
        this.age = age;
        Email = email;
        Phone = phone;
        this.diaChi = diaChi;
    }

    public String gettenNV() {
        return tenNV;
    }

    public void settenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public String getmaNV() {
        return maNV;
    }

    public void setmaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    @Override
    public String toString() {
        return gettenNV()+"_"+getmaNV()+"_"+getAge()+"_"+getEmail()+"_"+getPhone()+"_"+getDiaChi();
    }
}

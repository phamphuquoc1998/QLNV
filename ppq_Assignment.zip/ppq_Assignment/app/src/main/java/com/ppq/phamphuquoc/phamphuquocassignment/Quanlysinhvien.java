package com.ppq.phamphuquoc.phamphuquocassignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Quanlysinhvien extends AppCompatActivity {
    Button bntadd2 , bntedit2,bntdelete2;
    EditText tenNV, maNV , Age,email,phone,address;
    TextView tvcount2;
    ListView lsView2;
    ArrayList<NhanVien> lsNhanVien = new ArrayList<>();
    ArrayList<NhanVien> arrayAdapter;
    int vitri = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quanlysinhvien);
        tenNV = (EditText) findViewById(R.id.tenNV);
        maNV = (EditText) findViewById(R.id.maNV);
        Age = (EditText) findViewById(R.id.age);
        email = (EditText) findViewById(R.id.email);
        phone = (EditText) findViewById(R.id.phone);
        address = (EditText) findViewById(R.id.address);
        tvcount2 = (TextView) findViewById(R.id.tvcount2);
        lsNhanVien.add(new NhanVien("Quoc","1","20","quoc@gmail.com","330255","hcm"));
        lsNhanVien.add(new NhanVien("pham","2","20","pham@gmail.com","123013","hcm"));
        lsNhanVien.add(new NhanVien("Hphu","3","20","phu@gmail.com","197557","hcm"));
        bntadd2 = (Button) findViewById(R.id.btnadd2);
        bntedit2 = (Button) findViewById(R.id.btnedit2);
        bntdelete2 = (Button) findViewById(R.id.btndelete2);
        lsView2 = (ListView) findViewById(R.id.lsView2);
        final ArrayAdapter<NhanVien> arrayAdapter=
                new ArrayAdapter<NhanVien>(this, android.R.layout.simple_list_item_1, lsNhanVien);
        lsView2.setAdapter(arrayAdapter);
        bntadd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NhanVien st = new NhanVien();
                st.settenNV(tenNV.getText().toString());
                st.setmaNV(maNV.getText().toString());
                st.setAge(Age.getText().toString());
                st.setEmail(email.getText().toString());
                st.setPhone(phone.getText().toString());
                st.setDiaChi(address.getText().toString());
                lsNhanVien.add(st);
                tvcount2.setText("Count : "+ lsNhanVien.size());
                arrayAdapter.notifyDataSetChanged();
                tenNV.setText(" ");
                maNV.setText(" ");
                Age.setText(" ");
                email.setText(" ");
                phone.setText(" ");
                address.setText(" ");
            }
        });
        lsView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Item"+position,Toast.LENGTH_SHORT).show();
                NhanVien st = lsNhanVien.get(position);
                tenNV.setText(st.gettenNV());
                maNV.setText(st.getmaNV());
                Age.setText(st.getAge());
                email.setText(st.getEmail());
                phone.setText(st.getPhone());
                address.setText(st.getDiaChi());
                vitri = position;
            }
        });
        bntedit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NhanVien st = new NhanVien();
                st.settenNV(tenNV.getText().toString());
                st.setmaNV(maNV.getText().toString());
                st.setAge(Age.getText().toString());
                st.setEmail(email.getText().toString());
                st.setPhone(phone.getText().toString());
                st.setDiaChi(address.getText().toString());
                lsNhanVien.set(vitri,st);
                arrayAdapter.notifyDataSetChanged();
            }
        });
        bntdelete2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tenNV.setText(" ");
                maNV.setText(" ");
                Age.setText(" ");
                email.setText(" ");
                phone.setText(" ");
                address.setText(" ");
                lsNhanVien.remove(vitri);
                arrayAdapter.notifyDataSetChanged();
                tvcount2.setText("Count : "+ lsNhanVien.size());
            }
        });
    }
}
